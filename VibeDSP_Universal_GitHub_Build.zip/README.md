# VibeDSP Universal Beta 0.3

Prototipe Android untuk menguji efek audio Android. Versi ini mencoba membuat Equalizer, BassBoost, dan Virtualizer pada output-mix session ID 0.

## Build melalui GitHub Actions
1. Unggah ZIP ini ke repository GitHub dengan nama `VibeDSP_Universal_GitHub_Build.zip` (ganti ZIP lama).
2. Jalankan workflow `Build VibeDSP APK` pada tab Actions.
3. Unduh artifact `VibeDSP-APK`, ekstrak, lalu instal `app-debug.apk`.

## Batasan penting
- Build sukses hanya membuktikan kode berhasil dikompilasi, bukan bahwa efek benar-benar memengaruhi audio dari aplikasi lain.
- Efek audio pada output mix (session ID 0) bergantung pada vendor, ROM, kebijakan audio Android, dan efek yang tersedia. Jika ditolak atau tidak diterapkan sistem, aplikasi biasa tidak bisa memaksa pemrosesan seluruh audio aplikasi lain.
- Jangan menganggap status berhasil membuat objek efek sebagai jaminan bahwa YouTube Music atau aplikasi lain akan terdengar berubah. Uji dengan mendengarkan dan membandingkan.
