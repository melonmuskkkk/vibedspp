# VibeDSP Universal — starter project

Prototipe Android native (Kotlin) untuk Android 13 dan perangkat lain yang mendukung efek audio Android.

## Fitur prototipe
- Antarmuka gelap.
- EQ 5-band melalui Android `Equalizer` jika efek tersedia.
- Bass Boost dan Virtualizer Android jika tersedia.
- Bypass dan preset Flat/Bass+/Vocal.
- Tidak membutuhkan internet saat aplikasi berjalan.

## Build APK otomatis lewat GitHub Actions
1. Ekstrak ZIP ini.
2. Di GitHub, buat repository baru bernama `VibeDSP` dan set sebagai **Public** (agar paling mudah mengikuti langkah awal).
3. Unggah semua ISI folder proyek, termasuk folder tersembunyi `.github`. Pastikan file `.github/workflows/build.yml` ikut terunggah.
4. Buka tab **Actions** di repository. Jika diminta, aktifkan Actions.
5. Pilih workflow **Build VibeDSP APK** lalu tekan **Run workflow**. Workflow juga berjalan otomatis setelah push ke branch `main`.
6. Tunggu sampai proses selesai dengan tanda centang hijau. Buka run tersebut, cari **Artifacts**, lalu unduh `VibeDSP-debug-apk`.
7. Ekstrak hasil unduhan dan instal `app-debug.apk` di HP. Android mungkin meminta izin instal aplikasi dari sumber tersebut.

## Catatan teknis
- Ini prototipe sumber, bukan APK yang sudah dikompilasi atau diuji di perangkat fisik.
- Efek `Equalizer`, `BassBoost`, dan `Virtualizer` bergantung pada dukungan perangkat dan sesi audio; tidak dijamin memproses semua aplikasi.
- EQ UI contoh ini hanya mengatur lima pita awal yang diekspos oleh efek Equalizer. Kompatibilitas dan perilaku perlu diuji di HP.
- Proyek memakai Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Gradle 8.9, dan JDK 17.
- Untuk penggunaan pribadi, repository Private lebih baik; instruksi Public di atas hanya pilihan termudah untuk pemula.
