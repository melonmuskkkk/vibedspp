package com.feri.vibedsp

import android.app.Activity
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface

class MainActivity : Activity() {
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var audioSessionId = 0
    private var bypass = false
    private val purple = Color.rgb(155, 110, 255)
    private val bg = Color.rgb(16, 17, 22)
    private val card = Color.rgb(29, 30, 39)
    private val white = Color.rgb(245, 245, 250)
    private val muted = Color.rgb(170, 171, 190)
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        initEffects(0)
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "VibeDSP"
            textSize = 30f
            setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        root.addView(title)
        root.addView(TextView(this).apply {
            text = "UNIVERSAL AUDIO • BETA 0.1"
            textSize = 11f; setTextColor(purple); letterSpacing = .12f
        })
        status = TextView(this).apply {
            text = "Efek audio belum diaktifkan"
            textSize = 13f; setTextColor(muted); setPadding(0, dp(14), 0, dp(12))
        }
        root.addView(status)

        val toggle = Switch(this).apply {
            text = "DSP Aktif"
            textSize = 17f; setTextColor(white); isChecked = true
            setOnCheckedChangeListener { _, checked ->
                bypass = !checked
                applyEnabledState()
            }
        }
        addCard(root, toggle)

        val eqBox = section(root, "EQUALIZER", "Geser tiap pita untuk membentuk karakter suara.")
        val bands = listOf("Bass · 60 Hz", "Low-mid · 230 Hz", "Mid · 910 Hz", "Presence · 3.6 kHz", "Treble · 14 kHz")
        bands.forEachIndexed { index, label ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(5), 0, dp(5))
            }
            val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            line.addView(TextView(this).apply {
                text = label; textSize = 13f; setTextColor(white)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            val value = TextView(this).apply {
                text = "0 dB"; textSize = 12f; setTextColor(purple)
            }
            line.addView(value)
            row.addView(line)
            val seek = SeekBar(this).apply {
                max = 24; progress = 12
                progressTintList = android.content.res.ColorStateList.valueOf(purple)
                thumbTintList = android.content.res.ColorStateList.valueOf(purple)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                        val db = p - 12
                        value.text = "$db dB"
                        try {
                            val e = eq ?: return
                            if (index < e.numberOfBands) {
                                val range = e.bandLevelRange
                                val level = (db * 100).coerceIn(range[0].toInt(), range[1].toInt())
                                e.setBandLevel(index.toShort(), level.toShort())
                            }
                        } catch (_: Exception) { }
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            row.addView(seek)
            eqBox.addView(row)
        }

        val bassBox = section(root, "BASS ENGINE", "Efek memakai implementasi audio Android jika tersedia.")
        addSlider(bassBox, "Bass Boost", 0, 1000, 0) { value ->
            try { bass?.setStrength(value.toShort()) } catch (_: Exception) {}
        }
        addSlider(bassBox, "Virtualizer", 0, 1000, 0) { value ->
            try { virtualizer?.setStrength(value.toShort()) } catch (_: Exception) {}
        }

        val controlBox = section(root, "KONTROL", "Preset dasar untuk mulai mendengarkan.")
        val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Flat", "Bass+", "Vocal").forEach { name ->
            val button = Button(this).apply {
                text = name
                setTextColor(white)
                setOnClickListener {
                    val values = when (name) {
                        "Bass+" -> listOf(5, 3, 0, 1, 2)
                        "Vocal" -> listOf(-2, 0, 3, 4, 2)
                        else -> listOf(0, 0, 0, 0, 0)
                    }
                    // Update available EQ bands, limited by the effect's actual band count.
                    try {
                        val e = eq
                        if (e != null) for (i in 0 until minOf(e.numberOfBands.toInt(), values.size)) {
                            val r = e.bandLevelRange
                            e.setBandLevel(i.toShort(), (values[i] * 100).coerceIn(r[0].toInt(), r[1].toInt()).toShort())
                        }
                    } catch (_: Exception) {}
                    Toast.makeText(this@MainActivity, "Preset $name diterapkan jika didukung perangkat", Toast.LENGTH_SHORT).show()
                }
            }
            presetRow.addView(button, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        controlBox.addView(presetRow)

        root.addView(TextView(this).apply {
            text = "Catatan: Android/MIUI dapat membatasi efek pada aplikasi tertentu. Versi beta ini belum memproses seluruh audio sistem."
            textSize = 12f; setTextColor(muted); setPadding(0, dp(18), 0, 0)
        })
    }

    private fun section(parent: LinearLayout, heading: String, subtitle: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            setBackgroundColor(card)
        }
        val params = LinearLayout.LayoutParams(-1, -2)
        params.topMargin = dp(12)
        parent.addView(box, params)
        box.addView(TextView(this).apply {
            text = heading; textSize = 15f; setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = subtitle; textSize = 11f; setTextColor(muted)
            setPadding(0, dp(4), 0, dp(10))
        })
        return box
    }

    private fun addCard(parent: LinearLayout, child: View) {
        val box = LinearLayout(this).apply {
            setPadding(dp(14), dp(8), dp(14), dp(8)); setBackgroundColor(card)
            addView(child, LinearLayout.LayoutParams(-1, -2))
        }
        val p = LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(8)
        parent.addView(box, p)
    }

    private fun addSlider(parent: LinearLayout, label: String, min: Int, max: Int, initial: Int, onValue: (Int) -> Unit) {
        parent.addView(TextView(this).apply { text = label; textSize = 13f; setTextColor(white) })
        val seek = SeekBar(this).apply {
            this.max = max; progress = initial
            progressTintList = android.content.res.ColorStateList.valueOf(purple)
            thumbTintList = android.content.res.ColorStateList.valueOf(purple)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { onValue(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        parent.addView(seek)
    }

    private fun initEffects(sessionId: Int) {
        try {
            eq = Equalizer(0, sessionId).apply { enabled = true }
            bass = BassBoost(0, sessionId).apply { enabled = true }
            virtualizer = Virtualizer(0, sessionId).apply { enabled = true }
            status.text = "Efek dibuat. Efektivitas bergantung pada sesi audio/perangkat."
        } catch (e: Exception) {
            status.text = "Efek audio tidak tersedia pada perangkat ini."
        }
    }

    private fun applyEnabledState() {
        try {
            eq?.enabled = !bypass
            bass?.enabled = !bypass
            virtualizer?.enabled = !bypass
            status.text = if (bypass) "DSP bypass" else "DSP aktif jika didukung jalur audio"
        } catch (_: Exception) { }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        try { eq?.release() } catch (_: Exception) {}
        try { bass?.release() } catch (_: Exception) {}
        try { virtualizer?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
