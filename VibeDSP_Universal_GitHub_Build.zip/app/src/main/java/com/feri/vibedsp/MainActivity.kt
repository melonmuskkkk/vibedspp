package com.feri.vibedsp

import android.app.Activity
import android.media.MediaPlayer
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface

class MainActivity : Activity() {
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var player: MediaPlayer? = null
    private var bypass = false
    private val purple = Color.rgb(155, 110, 255)
    private val bg = Color.rgb(16, 17, 22)
    private val card = Color.rgb(29, 30, 39)
    private val white = Color.rgb(245, 245, 250)
    private val muted = Color.rgb(170, 171, 190)
    private lateinit var status: TextView
    private lateinit var playButton: Button
    private val eqSliders = mutableListOf<SeekBar>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        initPlayerAndEffects()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "VibeDSP"
            textSize = 30f
            setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "UNIVERSAL AUDIO • BETA 0.3"
            textSize = 11f; setTextColor(purple); letterSpacing = .12f
        })
        status = TextView(this).apply {
            text = "Menyiapkan audio uji…"
            textSize = 13f; setTextColor(muted); setPadding(0, dp(14), 0, dp(12))
        }
        root.addView(status)

        val playerBox = section(root, "TES AUDIO", "Efek diuji pada audio yang diputar di aplikasi ini.")
        playButton = Button(this).apply {
            text = "▶ Putar audio uji"
            setOnClickListener {
                val p = player
                if (p == null) {
                    status.text = "Audio uji belum siap."
                } else if (p.isPlaying) {
                    p.pause()
                    text = "▶ Lanjutkan audio uji"
                } else {
                    p.start()
                    text = "⏸ Jeda audio uji"
                    status.text = "Audio uji diputar. Geser EQ atau Bass Boost untuk mengetes."
                }
            }
        }
        playerBox.addView(playButton, LinearLayout.LayoutParams(-1, dp(48)))

        val toggle = Switch(this).apply {
            text = "DSP Aktif"
            textSize = 17f; setTextColor(white); isChecked = true
            setOnCheckedChangeListener { _, checked ->
                bypass = !checked
                applyEnabledState()
            }
        }
        addCard(root, toggle)

        val eqBox = section(root, "EQUALIZER 5 PITA", "Geser saat audio uji sedang diputar.")
        val bands = listOf("Bass · 60 Hz", "Low-mid · 230 Hz", "Mid · 910 Hz", "Presence · 3.6 kHz", "Treble · 14 kHz")
        bands.forEachIndexed { index, label ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(5), 0, dp(5))
            }
            val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            line.addView(TextView(this).apply {
                text = label; textSize = 13f; setTextColor(white)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            val value = TextView(this).apply {
                text = "0 dB"; textSize = 12f; setTextColor(purple)
            }
            line.addView(value)
            row.addView(line)
            val seek = SeekBar(this).apply {
                max = 24; progress = 12
                progressTintList = android.content.res.ColorStateList.valueOf(purple)
                thumbTintList = android.content.res.ColorStateList.valueOf(purple)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                        val db = p - 12
                        value.text = "$db dB"
                        if (user) applyEqBand(index, db)
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            eqSliders.add(seek)
            row.addView(seek)
            eqBox.addView(row)
        }

        val bassBox = section(root, "BASS ENGINE", "Efek ini juga bergantung pada dukungan perangkat.")
        addSlider(bassBox, "Bass Boost", 0, 1000, 0) { value ->
            try { bass?.setStrength(value.toShort()) } catch (_: Exception) {}
        }
        addSlider(bassBox, "Virtualizer", 0, 1000, 0) { value ->
            try { virtualizer?.setStrength(value.toShort()) } catch (_: Exception) {}
        }

        val controlBox = section(root, "PRESET", "Preset diterapkan ke sesi audio uji.")
        val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Flat", "Bass+", "Vocal").forEach { name ->
            val button = Button(this).apply {
                text = name
                setTextColor(white)
                setOnClickListener {
                    val values = when (name) {
                        "Bass+" -> listOf(5, 3, 0, 1, 2)
                        "Vocal" -> listOf(-2, 0, 3, 4, 2)
                        else -> listOf(0, 0, 0, 0, 0)
                    }
                    values.forEachIndexed { i, db ->
                        if (i < eqSliders.size) eqSliders[i].progress = (db + 12).coerceIn(0, 24)
                        applyEqBand(i, db)
                    }
                    Toast.makeText(this@MainActivity, "Preset $name diterapkan ke audio uji", Toast.LENGTH_SHORT).show()
                }
            }
            presetRow.addView(button, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        controlBox.addView(presetRow)

        root.addView(TextView(this).apply {
            text = "Mode output sistem dicoba melalui efek audio Android (sesi 0). Banyak ROM menolak atau membatasi ini. Jika status menyatakan mode sistem tidak tersedia, efek lintas aplikasi perlu dukungan ROM/root atau integrasi sistem."
            textSize = 12f; setTextColor(muted); setPadding(0, dp(18), 0, 0)
        })
    }

    private fun initPlayerAndEffects() {
        try {
            player = MediaPlayer.create(this, R.raw.test_audio)
            if (player == null) {
                status.text = "Audio uji tidak dapat dimuat."
                return
            }
            player?.setOnCompletionListener { playButton.text = "▶ Putar audio uji" }

            // Try Android output-mix session (sessionId 0) first. This is vendor/ROM dependent.
            if (createEffects(0)) {
                status.text = "Efek output sistem berhasil dibuat. Uji lagu dari aplikasi lain; hasil bergantung pada dukungan ROM."
            } else {
                val sessionId = player?.audioSessionId ?: 0
                if (sessionId > 0 && createEffects(sessionId)) {
                    status.text = "Mode output sistem tidak tersedia. Efek hanya terhubung ke audio uji di VibeDSP."
                } else {
                    status.text = "Efek audio tidak tersedia pada perangkat ini."
                }
            }
        } catch (e: Exception) {
            status.text = "Efek audio tidak tersedia: ${e.javaClass.simpleName}"
        }
    }

    private fun createEffects(sessionId: Int): Boolean {
        releaseEffects()
        return try {
            val newEq = Equalizer(0, sessionId)
            val newBass = BassBoost(0, sessionId)
            val newVirtualizer = Virtualizer(0, sessionId)
            newEq.enabled = !bypass
            newBass.enabled = !bypass
            newVirtualizer.enabled = !bypass
            eq = newEq
            bass = newBass
            virtualizer = newVirtualizer
            true
        } catch (_: Exception) {
            releaseEffects()
            false
        }
    }

    private fun releaseEffects() {
        try { eq?.release() } catch (_: Exception) {}
        try { bass?.release() } catch (_: Exception) {}
        try { virtualizer?.release() } catch (_: Exception) {}
        eq = null
        bass = null
        virtualizer = null
    }

    private fun applyEqBand(index: Int, db: Int) {
        try {
            val e = eq ?: return
            if (index < e.numberOfBands) {
                val range = e.bandLevelRange
                val level = (db * 100).coerceIn(range[0].toInt(), range[1].toInt())
                e.setBandLevel(index.toShort(), level.toShort())
            }
        } catch (_: Exception) {}
    }

    private fun section(parent: LinearLayout, heading: String, subtitle: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            setBackgroundColor(card)
        }
        val params = LinearLayout.LayoutParams(-1, -2)
        params.topMargin = dp(12)
        parent.addView(box, params)
        box.addView(TextView(this).apply {
            text = heading; textSize = 15f; setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = subtitle; textSize = 11f; setTextColor(muted)
            setPadding(0, dp(4), 0, dp(10))
        })
        return box
    }

    private fun addCard(parent: LinearLayout, child: View) {
        val box = LinearLayout(this).apply {
            setPadding(dp(14), dp(8), dp(14), dp(8)); setBackgroundColor(card)
            addView(child, LinearLayout.LayoutParams(-1, -2))
        }
        val p = LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(8)
        parent.addView(box, p)
    }

    private fun addSlider(parent: LinearLayout, label: String, min: Int, max: Int, initial: Int, onValue: (Int) -> Unit) {
        parent.addView(TextView(this).apply { text = label; textSize = 13f; setTextColor(white) })
        val seek = SeekBar(this).apply {
            this.max = max; progress = initial
            progressTintList = android.content.res.ColorStateList.valueOf(purple)
            thumbTintList = android.content.res.ColorStateList.valueOf(purple)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) onValue(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        parent.addView(seek)
    }

    private fun applyEnabledState() {
        try {
            eq?.enabled = !bypass
            bass?.enabled = !bypass
            virtualizer?.enabled = !bypass
            status.text = if (bypass) "DSP bypass" else "DSP aktif pada audio uji jika didukung"
        } catch (_: Exception) { }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        releaseEffects()
        super.onDestroy()
    }
}
