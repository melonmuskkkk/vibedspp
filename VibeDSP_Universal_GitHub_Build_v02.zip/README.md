# VibeDSP Universal — beta 0.2

Prototipe Android native untuk menguji efek Equalizer, Bass Boost, dan Virtualizer pada audio yang diputar di dalam aplikasi VibeDSP.

## Perubahan beta 0.2
- Menambahkan tombol Putar/Jeda audio uji.
- Efek dibuat menggunakan audio session milik pemutar audio, bukan session ID 0.
- Pengaturan EQ hanya diterapkan ketika slider digeser.
- Preset Flat, Bass+, dan Vocal memperbarui EQ.

## Batasan
Versi ini hanya untuk menguji efek pada audio uji di dalam VibeDSP. Efek tidak otomatis mengubah audio YouTube Music atau seluruh sistem Android. Efek juga bergantung pada dukungan vendor/perangkat.

## Build via GitHub Actions
Gunakan workflow `.github/workflows/build.yml` di repository, lalu unggah ZIP ini dengan nama `VibeDSP_Universal_GitHub_Build.zip` dan jalankan workflow `Build VibeDSP APK`. Hasil APK debug akan tersedia di Artifacts.
